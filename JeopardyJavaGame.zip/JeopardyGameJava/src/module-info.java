/**
 * 
 */
/**
 * 
 */
module JeopardyGameJava {
	requires java.desktop;
}