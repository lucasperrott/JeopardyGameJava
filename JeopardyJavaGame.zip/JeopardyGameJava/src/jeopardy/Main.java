package jeopardy;

public class Main {
    public static void main(String[] args) {
        GameBoard gameBoard = new GameBoard();
    }
}
